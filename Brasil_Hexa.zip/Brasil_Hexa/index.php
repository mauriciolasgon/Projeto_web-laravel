<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="assets/css/style.css ">
</head>
<body>
       <div class="box_login">
        <div class="capa">
          </div>

        <h1>FAÇA SEU LOGIN</h1>
        <form>
            <input type="number_format" name"RA/RP" placeholder="RA/RP">
            <input type="password" name"SENHA" placeholder="SENHA">

            <button class="btn-login">ENTRAR</button>
        </form>
        <div class="ney">

    </div>
</body>
</html>