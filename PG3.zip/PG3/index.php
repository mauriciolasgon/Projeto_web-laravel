<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="assets/css/style.css ">
</head>
<body>
     <div class="box_background"> 
       
         <div class="faixa">
                </div>
                 <div class="caixao"> 
                    </div>   
                        <div class="caixa"> 
                            </div> 
                            <div class="ronaldo">
                                </div>
                                <div class="brlogo">
                                    </div>
                                    <h1>Professores</h1>
                                        </div>
                                        <h2>MATERIA_1</h2>
     
</body>
</html>