<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="assets/css/style.css ">
</head>
<body>
     <div class="box_background"> 
       
         <div class="faixa">
             <h1>FILMES FAVORITOS DO</h1>
                </div>                
                 <div class="cartaz">
                     </div>
                     <div class="filme1">
                        </div>
                            <div class="filme2">
                             </div>
                                 <div class="filme3">
                                 </div>
                         
                       
</body>
</html>