<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="assets/css/style.css ">
</head>
<body>
     <div class="box_background">
        <div class="faixa">
            <div class="ney">
                    <div class="caixa1">
                      <div class="caixa2">
                         <div class="caixa3">
                            <div class="caixa4">
                                 <div class="caixa5">
                                     <div class="caixa6">
                                      </div>
                                        <div class="caixao">
                                            <div class="cal">
                                             </div>
                                             <div class="osc">
                                                </div>
                                               <div class="pi">
                                                </div>
                                                   <div class="eng">
                                                     </div>
                                                       <div class="teo">
                                                          </div>
                                                            <div class="rob">
                                                               </div>
                                                                 <div class="lup">
                                                                      </div>
                                                                        <div class="lup">
                                                                        </div>    
                                                                                         
                                            
        <form>
             <button class="btn-materia1">Cálculo I</button>               
                 <button class="btn-materia2">OSC</button>                   
                     <button class="btn-materia3">PI: Web</button>                       
                         <button class="btn-materia4">Robótica</button>                       
                             <button class="btn-materia5">Teologia</button>                                
                               <button class="btn-materia6">Fund. Eng.</button>
                                 <input type="text" name"Pesquisar" placeholder="Pesquisar">
                                   <button class="btn-busca"></button>

        </form>  
                                                                          
     </div>    
     
</body>
</html>